package com.includenavigator.app

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Collections
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // <input type=file> bridge
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // Files found by the native folder picker; the page fetches them lazily by index.
    private val folderFiles: MutableList<Uri> = Collections.synchronizedList(mutableListOf())

    // Pending "save as" data (written once the user picks a destination).
    private var pendingSave: ByteArray? = null
    private var pendingSaveName: String = ""

    private val extRe = Regex("""\.(h|hpp|hh|hxx|inl|c|cpp|cc|cxx|rc)$""", RegexOption.IGNORE_CASE)
    private val skipDirs = setOf("debug", "release", "x64", "obj")

    companion object {
        private const val REQ_FILES = 1001
        private const val REQ_FOLDER = 1002
        private const val REQ_SAVE = 1003
        private const val HOST = "appassets.androidplatform.net"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/saf/", WebViewAssetLoader.PathHandler { path -> openFolderFile(path) })
            .build()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.textZoom = 100
            addJavascriptInterface(Bridge(), "AndroidBridge")

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)
            }

            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    filePathCallback: ValueCallback<Array<Uri>>,
                    fileChooserParams: FileChooserParams
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = filePathCallback
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"   // source files have no reliable MIME type
                        putExtra(
                            Intent.EXTRA_ALLOW_MULTIPLE,
                            fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                        )
                    }
                    return try {
                        startActivityForResult(Intent.createChooser(intent, "Select source files"), REQ_FILES)
                        true
                    } catch (e: Exception) {
                        fileCallback = null
                        false
                    }
                }
            }
        }
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("window.__androidBack && window.__androidBack()") { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("https://$HOST/assets/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    // ------------------------------------------------------------------ results

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILES -> {
                var uris: Array<Uri>? = null
                if (resultCode == Activity.RESULT_OK && data != null) {
                    val clip = data.clipData
                    uris = when {
                        clip != null -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                        data.data != null -> arrayOf(data.data!!)
                        else -> null
                    }
                }
                fileCallback?.onReceiveValue(uris)
                fileCallback = null
            }

            REQ_FOLDER -> {
                val tree = data?.data
                if (resultCode == Activity.RESULT_OK && tree != null) scanFolder(tree)
            }

            REQ_SAVE -> {
                val dest = data?.data
                val bytes = pendingSave
                pendingSave = null
                if (resultCode == Activity.RESULT_OK && dest != null && bytes != null) {
                    try {
                        contentResolver.openOutputStream(dest, "wt")?.use { it.write(bytes) }
                        status("Saved $pendingSaveName. To update your project, replace the original file with it.")
                    } catch (e: Exception) {
                        status("Save failed: ${e.message}")
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ folder scan

    private fun scanFolder(treeUri: Uri) {
        status("Reading folder…")
        thread {
            try {
                val rootId = DocumentsContract.getTreeDocumentId(treeUri)
                val rootName = displayName(DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)) ?: "folder"
                folderFiles.clear()
                val items = JSONArray()
                walk(treeUri, rootId, "", items)
                val json = JSONObject.quote(rootName)
                runOnUiThread {
                    webView.evaluateJavascript("window.__onNativeFolder($json, $items)", null)
                }
            } catch (e: Exception) {
                val msg = JSONObject.quote(e.message ?: e.toString())
                runOnUiThread {
                    webView.evaluateJavascript("window.__onNativeFolder('', null, $msg)", null)
                }
            }
        }
    }

    private fun walk(tree: Uri, parentId: String, prefix: String, out: JSONArray) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val name = c.getString(1) ?: continue
                val isDir = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                if (isDir) {
                    if (name.startsWith(".") || name.lowercase(Locale.ROOT) in skipDirs) continue
                    walk(tree, id, "$prefix$name/", out)
                } else if (extRe.containsMatchIn(name)) {
                    val index = folderFiles.size
                    folderFiles.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                    out.put(JSONObject().put("p", "$prefix$name").put("u", "https://$HOST/saf/$index"))
                }
            }
        }
    }

    private fun displayName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    private fun openFolderFile(path: String): WebResourceResponse? {
        val index = path.trim('/').toIntOrNull() ?: return null
        val uri = folderFiles.getOrNull(index) ?: return null
        return try {
            val stream = contentResolver.openInputStream(uri) ?: return null
            WebResourceResponse("application/octet-stream", null, stream)
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------ JS bridge

    private fun status(msg: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.__setStatus(${JSONObject.quote(msg)})", null)
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                @Suppress("DEPRECATION")
                startActivityForResult(intent, REQ_FOLDER)
            }
        }

        @JavascriptInterface
        fun saveFile(name: String, base64: String) {
            pendingSave = Base64.decode(base64, Base64.DEFAULT)
            pendingSaveName = name
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, name)
                }
                @Suppress("DEPRECATION")
                startActivityForResult(intent, REQ_SAVE)
            }
        }

        @JavascriptInterface
        fun shareFile(name: String, base64: String) {
            try {
                val dir = File(cacheDir, "share").apply { mkdirs() }
                val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val file = File(dir, safeName)
                file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    clipData = ClipData.newRawUri(name, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(send, "Share $name")) }
            } catch (e: Exception) {
                status("Share failed: ${e.message}")
            }
        }
    }
}
