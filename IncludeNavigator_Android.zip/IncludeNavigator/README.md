# Include Navigator (Android)

Your `include_navigator_android.html` wrapped in a native Android app (WebView).

## Build the APK
1. Install **Android Studio** (Koala or newer).
2. `File > Open` and choose this `IncludeNavigator` folder. Let Gradle sync (needs internet the first time).
3. Plug in a phone (USB debugging on) or start an emulator and press **Run**.
4. For a shareable APK: `Build > Build App Bundle(s) / APK(s) > Build APK(s)`.
   The file lands in `app/build/outputs/apk/debug/app-debug.apk`; copy it to your phone and install it.

## What changed vs. the plain HTML
The UI is `app/src/main/assets/index.html` (same as yours plus small hooks). Native code is in
`MainActivity.kt` and adds what a plain WebView cannot do:
- **+ Add folder** uses Android's folder picker (WebView can't do `webkitdirectory`).
  Files are read lazily, only when you open them.
- **Save copy** opens the system "Save as" dialog (blob downloads don't work in WebView).
- **Share** opens the Android share sheet.
- **Back button** goes to the previous file / closes the panel / leaves edit mode before exiting.

Dark/light mode follows the phone as before.

## Build without Android Studio (GitHub Actions)
1. Create a free GitHub account and a new repository (e.g. `IncludeNavigator`).
2. Upload **everything in this folder** to it, including the hidden `.github` folder
   (easiest: on the repo page choose *Add file > Upload files* and drag the whole folder contents in;
   if the `.github` folder is skipped, create the file `.github/workflows/build-apk.yml` manually and paste its contents).
3. Open the **Actions** tab. The build starts automatically (or choose *Build APK > Run workflow*).
4. When it shows a green check (about 3-5 minutes), open the run and download
   **IncludeNavigator-debug-apk** from *Artifacts*. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone and install it (allow "install unknown apps" when asked).
